export default function Loading() {
  return <img src="public\loading.svg" alt="loading..." />;
}
